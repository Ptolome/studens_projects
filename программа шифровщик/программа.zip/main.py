#code

import tkinter as tk
from tkinter import END

root = tk.Tk()

# НАЗВАНИЕ ПРОГРАММЫ
root.title('Шифратор дешифратор')

# ПАРАМЕТРЫ ОКНА
root.geometry("1150x700")
root.attributes('-topmost', 1)
root.attributes('-topmost', 0)
root["bg"] ="#ECEAF8"
root.minsize()
root.wm_attributes('-transparentcolor', '#ab23ff')


# Add Image
скопировать = tk.PhotoImage(file="кнопка скопировать (3).png")

вставить = tk.PhotoImage(file="вставить.png")

design = tk.PhotoImage(file="Designe.png")

удалить = tk.PhotoImage(file="удалить.png")


def copy():
    print('copy')

def vst():
    print('vst')

def shifr():
    kod = ''
    text = e.get()
    for i in text:
        if len(str(ord(i))) % 4 == 3:
            kod += '0' + str(ord(i))
        if len(str(ord(i))) % 4 == 2:
            kod += '00' + str(ord(i))
        if len(str(ord(i))) % 4 == 1:
            kod += '000' + str(ord(i))
        if len(str(ord(i))) % 4 == 0:
            kod += str(ord(i))
    print(kod)
    c.insert(0, kod)

def rasshifr():
    a = ''
    kod = c.get()
    text1 = ''
    for i in kod:
        a += i
        if len(a) % 4 == 0:
            text1 += chr(int(a))
            a = ''
    print(text1)
    e.insert(0, text1)

def x1():
    e.delete(0, END)

def x2():
    c.delete(0, END)

#просто фотки на фоне
designe = tk.Label(root,
                   image=design)
designe.pack()

# ВИДЖЕТЫ
img = tk.Button(root,
                image=скопировать,
                borderwidth=0,
                command = copy,
                bg='#02223A',
                activebackground='#02223A')
img.place(x=910, y=462)

img = tk.Button(root,
                image=скопировать,
                borderwidth=0,
                command = copy,
                bg='#02223A',
                activebackground='#02223A')
img.place(x=910, y=267)

img1 = tk.Button(root,
                 image=вставить,
                 borderwidth=0,
                 command=vst,
                 bg='#02223A',
                 activebackground='#02223A'
                 )
img1.place(x=860, y=267)

img1 = tk.Button(root,
                 image=вставить,
                 borderwidth=0,
                 command=vst,
                 bg='#02223A',
                 activebackground='#02223A'
                 )
img1.place(x=860, y=462)

x1 = tk.Button(root,
               image=удалить,
               command=x1,
               bg='#02223A',
               activebackground='#02223A',
               borderwidth=0)
x1.place(x=960, y=267)

x2 = tk.Button(root,
               image=удалить,
               command=x2,
               bg='#02223A',
               activebackground='#02223A',
               borderwidth=0)
x2.place(x=960, y=462)

rasshifr = tk.Button(root,
                text='РАСШИФРОВАТЬ',
                command=rasshifr,
                font=('Arial', 14, 'bold'),
                bg='#02223A',
                fg='#80D7CF',
                activebackground='#02223A',
                activeforeground='#80D7CF',
                borderwidth=0
                )
rasshifr.place(x=10, y=462, height=30)

shifr = tk.Button(root,
                text='ЗАШИФРОВАТЬ',
                command=shifr,
                font=('Arial', 14, 'bold'),
                bg='#02223A',
                fg='#80D7CF',
                activebackground='#02223A',
                activeforeground='#80D7CF',
                borderwidth=0
                )
shifr.place(x=10, y=267, height=30)

# поля ввода
e = tk.Entry(root,
             font=16)
e.place(x=200, y=268, width=650, height=30)

c = tk.Entry(root,
             font=16)
c.place(x=200, y=462, width=650, height=30)

# КОНЕЦ
root.mainloop()